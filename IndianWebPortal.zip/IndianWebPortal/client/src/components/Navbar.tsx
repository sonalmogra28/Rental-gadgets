import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export default function Navbar() {
  return (
    <nav className="bg-white border-b border-gray-200 py-4">
      <div className="container mx-auto px-4 flex items-center justify-between">
        <Link href="/">
          <a className="text-2xl font-bold text-primary">Team जुगाड़</a>
        </Link>

        <div className="flex gap-4">
          <Button variant="ghost" className="text-gray-600 hover:text-primary" asChild>
            <Link href="/">About Us</Link>
          </Button>
          <Button variant="ghost" className="text-gray-600 hover:text-primary" asChild>
            <Link href="/products">Projects</Link>
          </Button>
          <Button variant="default" className="bg-primary hover:bg-primary/90" asChild>
            <Link href="/contact">Join Team</Link>
          </Button>
        </div>
      </div>
    </nav>
  );
}