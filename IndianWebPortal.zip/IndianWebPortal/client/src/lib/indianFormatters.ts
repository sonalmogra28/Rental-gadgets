export function formatINR(amount: number): string {
  const formatter = new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  });
  return formatter.format(amount);
}

export function formatIndianNumber(num: number): string {
  return num.toLocaleString('en-IN');
}

export function formatIndianPhone(phone: string): string {
  // Format as +91 XXXXX XXXXX
  if (phone.length !== 10) return phone;
  return `+91 ${phone.slice(0,5)} ${phone.slice(5)}`;
}
