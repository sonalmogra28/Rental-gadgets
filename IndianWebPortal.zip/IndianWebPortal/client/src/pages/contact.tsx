import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { PhoneIcon, MailIcon, MapPinIcon } from "lucide-react";
import { z } from "zod";
import { insertContactSchema, type InsertContactMessage } from "@shared/schema";
import { indianPhoneSchema, indianStates } from "@/lib/indianValidators";
import { apiRequest } from "@/lib/queryClient";

const contactFormSchema = insertContactSchema.extend({
  phone: indianPhoneSchema,
  state: z.string().min(1, "Please select your state"),
  inquiryType: z.enum(["business", "rental", "general"], {
    required_error: "Please select inquiry type",
  }),
  company: z.string().optional(),
  budget: z.string().optional(),
});

export default function Contact() {
  const { toast } = useToast();

  const form = useForm<InsertContactMessage & { state: string, inquiryType: string, company?: string, budget?: string }>({
    resolver: zodResolver(contactFormSchema),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
      message: "",
      state: "",
      inquiryType: "general",
      company: "",
      budget: "",
    }
  });

  const mutation = useMutation({
    mutationFn: async (data: InsertContactMessage) => {
      await apiRequest("POST", "/api/contact", data);
    },
    onSuccess: () => {
      toast({
        title: "Message Sent",
        description: "We'll get back to you soon!",
      });
      form.reset();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive"
      });
    }
  });

  const watchInquiryType = form.watch("inquiryType");

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-5xl font-bold mb-6 text-primary">Connect with Team Jugaad</h1>
          <p className="text-lg mb-4 text-gray-600">
            Whether you're interested in renting gadgets, becoming a business partner,
            or just want to learn more about our services, we're here to help.
          </p>
        </div>

        {/* Quick Contact Info */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3 mb-2">
                <PhoneIcon className="h-5 w-5 text-primary" />
                <h3 className="font-semibold">Call Us</h3>
              </div>
              <p className="text-gray-600">+91 98765 43210</p>
              <p className="text-sm text-gray-500">Mon-Sat: 9AM to 6PM</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3 mb-2">
                <MailIcon className="h-5 w-5 text-primary" />
                <h3 className="font-semibold">Email Us</h3>
              </div>
              <p className="text-gray-600">contact@teamjugaad.in</p>
              <p className="text-sm text-gray-500">24/7 Support</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3 mb-2">
                <MapPinIcon className="h-5 w-5 text-primary" />
                <h3 className="font-semibold">Visit Us</h3>
              </div>
              <p className="text-gray-600">Ramgarh Cantt, Jharkhand</p>
              <p className="text-sm text-gray-500">Headquarters</p>
            </CardContent>
          </Card>
        </div>

        {/* Coverage Areas */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-6 text-center">Our Coverage Areas</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              "Mumbai", "Delhi", "Bangalore", "Hyderabad",
              "Chennai", "Kolkata", "Pune", "Ahmedabad"
            ].map((city) => (
              <div key={city} className="bg-primary/5 p-3 rounded-lg text-center">
                <p className="font-medium text-primary">{city}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Contact Form */}
        <Card className="mb-12">
          <CardHeader>
            <CardTitle>Send Us a Message</CardTitle>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit((data) => mutation.mutate(data))} className="space-y-4">
                <FormField
                  control={form.control}
                  name="inquiryType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Type of Inquiry</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select inquiry type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="business">Business Partnership</SelectItem>
                          <SelectItem value="rental">Rental Query</SelectItem>
                          <SelectItem value="general">General Inquiry</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Name</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email</FormLabel>
                      <FormControl>
                        <Input type="email" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="phone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Phone</FormLabel>
                      <FormControl>
                        <Input placeholder="10 digit mobile number" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {watchInquiryType === "business" && (
                  <>
                    <FormField
                      control={form.control}
                      name="company"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Company Name</FormLabel>
                          <FormControl>
                            <Input {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="budget"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Investment Budget</FormLabel>
                          <FormControl>
                            <Input {...field} placeholder="Optional" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </>
                )}

                <FormField
                  control={form.control}
                  name="state"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>State</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select your state" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {indianStates.map((state) => (
                            <SelectItem key={state} value={state}>{state}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="message"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Message</FormLabel>
                      <FormControl>
                        <Textarea 
                          {...field} 
                          placeholder={
                            watchInquiryType === "business" 
                              ? "Tell us about your business and how you'd like to partner with us"
                              : watchInquiryType === "rental"
                              ? "Tell us about your gadget requirements and rental duration"
                              : "How can we help you?"
                          }
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button type="submit" className="w-full" disabled={mutation.isPending}>
                  {mutation.isPending ? "Sending..." : "Send Message"}
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>

        {/* FAQ Section */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-6 text-center">Frequently Asked Questions</h2>
          <Accordion type="single" collapsible>
            <AccordionItem value="deposit">
              <AccordionTrigger>What is the security deposit?</AccordionTrigger>
              <AccordionContent>
                The security deposit varies by gadget but typically ranges from 20-50% of the device's value. It's fully refundable upon return of the device in good condition.
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="duration">
              <AccordionTrigger>What are the rental durations available?</AccordionTrigger>
              <AccordionContent>
                We offer flexible rental periods: daily, weekly, and monthly. Longer durations come with significant discounts.
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="damage">
              <AccordionTrigger>What happens if the device gets damaged?</AccordionTrigger>
              <AccordionContent>
                We provide insurance options for accidental damage. Without insurance, repair costs will be deducted from the security deposit.
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="delivery">
              <AccordionTrigger>Do you offer delivery?</AccordionTrigger>
              <AccordionContent>
                Yes, we offer free delivery and pickup for rentals within city limits. Additional charges apply for other locations.
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </section>

        {/* Team Section */}
        <section>
          <h2 className="text-2xl font-bold mb-6 text-center">Meet Our Team</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {[
              {
                name: "Mr. Yash",
                role: "Founder",
                description: "Visionary leader driving innovation in gadget rentals"
              },
              {
                name: "Miss Zakiya",
                role: "Co-Founder",
                description: "Strategic planner and business development expert"
              },
              {
                name: "Miss Aatufa",
                role: "COO",
                description: "Operations specialist ensuring smooth service delivery"
              },
              {
                name: "Miss Satyam",
                role: "CFO",
                description: "Financial strategist managing growth and investments"
              }
            ].map((member) => (
              <Card key={member.name}>
                <CardContent className="pt-6">
                  <h3 className="font-bold text-lg mb-1">{member.name}</h3>
                  <p className="text-primary font-medium mb-2">{member.role}</p>
                  <p className="text-gray-600 text-sm">{member.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}