import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function Home() {
  return (
    <div className="flex flex-col gap-8">
      {/* Hero Section */}
      <section className="bg-primary/5">
        <div className="py-24">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-5xl font-bold mb-6 text-primary">Team जुगाड़ (Jugaad)</h1>
            <p className="text-xl mb-4 text-gray-600">Revolutionizing Gadget Rentals in India</p>
            <p className="text-lg mb-8 text-gray-500">Making high-end gadgets accessible to everyone through smart rentals</p>
            <div className="flex gap-4 justify-center">
              <Button asChild size="lg" className="bg-primary hover:bg-primary/90">
                <Link href="/products">Explore Gadgets</Link>
              </Button>
              <Button asChild size="lg" variant="outline">
                <Link href="/contact">Partner With Us</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Business Pitch Section */}
      <section className="container mx-auto px-4 py-12">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-4 text-primary">Our Business Vision</h2>
          <p className="text-lg mb-8 text-gray-600">
            In a world where technology evolves rapidly, owning every gadget isn't practical.
            Team Jugaad brings you an innovative rental solution - high-quality gadgets
            at a fraction of the cost, whenever you need them.
          </p>
        </div>
      </section>

      {/* Value Proposition */}
      <section className="bg-gray-50 py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12 text-primary">Why Choose Us?</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                title: "Affordable Access",
                icon: "💰",
                description: "Premium gadgets at rental prices"
              },
              {
                title: "Quality Assured",
                icon: "✨",
                description: "Well-maintained, latest devices"
              },
              {
                title: "Flexible Plans",
                icon: "📅",
                description: "Rent daily, weekly, or monthly"
              }
            ].map((value) => (
              <div 
                key={value.title} 
                className="bg-white p-6 rounded-lg shadow-sm border border-gray-100 text-center hover:shadow-md transition-shadow"
              >
                <div className="text-4xl mb-4">{value.icon}</div>
                <h3 className="text-2xl font-bold mb-2 text-primary">{value.title}</h3>
                <p className="text-gray-600">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Market Stats */}
      <section className="container mx-auto px-4 py-16">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12 text-primary">Market Opportunity</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-white p-8 rounded-lg shadow-sm border border-gray-100">
              <h3 className="text-2xl font-bold mb-4">₹50,000 Cr+</h3>
              <p className="text-gray-600">Potential market size for gadget rentals in India by 2025</p>
            </div>
            <div className="bg-white p-8 rounded-lg shadow-sm border border-gray-100">
              <h3 className="text-2xl font-bold mb-4">70% Growth</h3>
              <p className="text-gray-600">Year-over-year growth in rental gadget demand</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}