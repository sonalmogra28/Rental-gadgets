import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { formatINR } from "@/lib/indianFormatters";
import type { Product } from "@shared/schema";

export default function Products() {
  const { data: products, isLoading } = useQuery<Product[]>({
    queryKey: ["/api/products"]
  });

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[...Array(6)].map((_, i) => (
            <Card key={i}>
              <CardHeader>
                <Skeleton className="h-40 w-full" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-4 w-3/4 mb-2" />
                <Skeleton className="h-4 w-1/2" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  const calculatePrice = (basePrice: number, duration: 'daily' | 'weekly' | 'monthly') => {
    const multipliers = {
      daily: 1,
      weekly: 6, // 7 days for price of 6
      monthly: 20 // 30 days for price of 20
    };
    return basePrice * multipliers[duration];
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-3xl mx-auto text-center mb-12">
        <h1 className="text-3xl font-bold mb-4">Available Gadgets for Rent</h1>
        <p className="text-gray-600">
          Choose from our selection of premium gadgets available for rent.
          Flexible rental periods with special discounts on weekly and monthly plans.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {products?.map((product) => (
          <Card key={product.id} className="overflow-hidden">
            <CardHeader className="p-0">
              <img 
                src={product.image} 
                alt={product.name}
                className="w-full h-48 object-cover"
              />
            </CardHeader>
            <CardContent className="p-6">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <CardTitle className="mb-2">{product.name}</CardTitle>
                  <p className="text-sm text-muted-foreground">{product.category}</p>
                </div>
              </div>
              <p className="text-muted-foreground mb-4">{product.description}</p>

              <Tabs defaultValue="daily" className="w-full">
                <TabsList className="grid w-full grid-cols-3 mb-4">
                  <TabsTrigger value="daily">Daily</TabsTrigger>
                  <TabsTrigger value="weekly">Weekly</TabsTrigger>
                  <TabsTrigger value="monthly">Monthly</TabsTrigger>
                </TabsList>
                <TabsContent value="daily" className="text-center mb-4">
                  <p className="text-lg font-bold text-primary">{formatINR(calculatePrice(product.price, 'daily'))}</p>
                  <p className="text-sm text-muted-foreground">per day</p>
                </TabsContent>
                <TabsContent value="weekly" className="text-center mb-4">
                  <p className="text-lg font-bold text-primary">{formatINR(calculatePrice(product.price, 'weekly'))}</p>
                  <p className="text-sm text-muted-foreground">per week (7 days)</p>
                  <p className="text-xs text-green-600">Save 14%</p>
                </TabsContent>
                <TabsContent value="monthly" className="text-center mb-4">
                  <p className="text-lg font-bold text-primary">{formatINR(calculatePrice(product.price, 'monthly'))}</p>
                  <p className="text-sm text-muted-foreground">per month (30 days)</p>
                  <p className="text-xs text-green-600">Save 33%</p>
                </TabsContent>
              </Tabs>

              <Button className="w-full">Book Now</Button>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Rental Process Section */}
      <section className="mt-16">
        <h2 className="text-2xl font-bold text-center mb-8">How Rental Works</h2>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {[
            {
              title: "Choose Gadget",
              description: "Browse our collection and select your desired gadget"
            },
            {
              title: "Select Duration",
              description: "Pick your rental duration - daily, weekly, or monthly"
            },
            {
              title: "Book & Pay",
              description: "Complete the booking process with secure payment"
            },
            {
              title: "Enjoy & Return",
              description: "Use the gadget and return it at the end of rental period"
            }
          ].map((step, index) => (
            <div key={index} className="text-center">
              <div className="bg-primary/10 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-4">
                <span className="text-primary font-bold">{index + 1}</span>
              </div>
              <h3 className="font-bold mb-2">{step.title}</h3>
              <p className="text-sm text-gray-600">{step.description}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}