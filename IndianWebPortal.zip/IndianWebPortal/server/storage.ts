import { users, type User, type InsertUser } from "@shared/schema";
import { products, contactMessages, type Product, type InsertProduct, type ContactMessage, type InsertContactMessage } from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getProducts(): Promise<Product[]>;
  createContactMessage(message: InsertContactMessage): Promise<ContactMessage>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private products: Map<number, Product>;
  private contactMessages: Map<number, ContactMessage>;
  currentId: number;
  private productId: number;
  private messageId: number;

  constructor() {
    this.users = new Map();
    this.products = new Map();
    this.contactMessages = new Map();
    this.currentId = 1;
    this.productId = 1;
    this.messageId = 1;

    // Add sample rental gadgets
    const sampleProducts: InsertProduct[] = [
      {
        name: "DJI Mavic Air 2",
        description: "Professional drone for aerial photography and videography",
        price: 2499,
        image: "https://images.unsplash.com/photo-1579829366248-204fe8413f31",
        category: "Drones"
      },
      {
        name: "Sony A7 III",
        description: "Full-frame mirrorless camera with 4K video",
        price: 3999,
        image: "https://images.unsplash.com/photo-1516724562728-afc4865086e7",
        category: "Cameras"
      },
      {
        name: "MacBook Pro M1",
        description: "Latest Apple laptop for professional work",
        price: 4999,
        image: "https://images.unsplash.com/photo-1611186871348-b1ce696e52c9",
        category: "Laptops"
      },
      {
        name: "Oculus Quest 2",
        description: "Virtual reality headset for immersive experiences",
        price: 1999,
        image: "https://images.unsplash.com/photo-1622979135225-d2ba269cf1ac",
        category: "VR Headsets"
      }
    ];

    sampleProducts.forEach(product => {
      const id = this.productId++;
      this.products.set(id, { ...product, id });
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getProducts(): Promise<Product[]> {
    return Array.from(this.products.values());
  }

  async createContactMessage(message: InsertContactMessage): Promise<ContactMessage> {
    const id = this.messageId++;
    const contactMessage: ContactMessage = { ...message, id };
    this.contactMessages.set(id, contactMessage);
    return contactMessage;
  }
}

export const storage = new MemStorage();